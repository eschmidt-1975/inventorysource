# ChatGPT Read-Only API Setup — V18.1

V18.1 adds named/scoped API credentials while remaining backward compatible with the existing `LIONEL_API_TOKEN`.

## Recommended setup

Keep the existing administrative token. Create a separate read-only token for ChatGPT:

```bash
openssl rand -hex 32
```

Edit the existing server environment file:

```bash
sudo nano /etc/lionel-catalog.env
```

Keep the existing line and add the new one:

```text
LIONEL_API_TOKEN=<existing-admin-token>
LIONEL_CHATGPT_API_TOKEN=<new-read-only-token>
```

Do not place either token in GitHub.

Restart the app:

```bash
sudo systemctl daemon-reload
sudo systemctl restart lionel-catalog
sudo systemctl status lionel-catalog
```

## Verify the read-only token

```bash
curl "https://trains.signallosscalculator.com/api/v1/auth/me" \
  -H "Authorization: Bearer YOUR_CHATGPT_TOKEN"
```

Expected scopes:

```json
{
  "success": true,
  "token_name": "ChatGPT Read Only",
  "scopes": ["read:intake", "read:inventory", "read:photos"]
}
```

Then test Session #2:

```bash
curl "https://trains.signallosscalculator.com/api/v1/intake/sessions/2" \
  -H "Authorization: Bearer YOUR_CHATGPT_TOKEN"
```

## Verify that writes are blocked

This request should return HTTP 403 with the ChatGPT token:

```bash
curl -i -X POST "https://trains.signallosscalculator.com/api/v1/items" \
  -H "Authorization: Bearer YOUR_CHATGPT_TOKEN" \
  -F "name=SHOULD NOT BE CREATED"
```

The dedicated token intentionally does not have `write:inventory`.

## Scopes

- `read:inventory` — item metadata, groups, statuses.
- `read:photos` — original catalog/intake image files.
- `read:intake` — intake sessions and grouping metadata.
- `write:inventory` — create inventory items or add photos. Administrative token only by default.
- `write:proposals` — reserved for the later review/proposal workflow. V18.1 does not implement proposal writes yet.

## Existing administrative token

`LIONEL_API_TOKEN` remains fully compatible and receives all currently defined scopes. Existing scripts therefore continue working after the upgrade.

## Optional multiple named tokens

For more than the built-in admin + ChatGPT pair, create `/etc/lionel-catalog-api-tokens.json`:

```json
{
  "tokens": [
    {
      "name": "Dad ChatGPT Read Only",
      "token": "PASTE_A_SEPARATE_RANDOM_TOKEN_HERE",
      "scopes": ["read:inventory", "read:photos", "read:intake"]
    }
  ]
}
```

Protect it:

```bash
sudo chown root:root /etc/lionel-catalog-api-tokens.json
sudo chmod 600 /etc/lionel-catalog-api-tokens.json
sudo systemctl restart lionel-catalog
```

Never commit this file to GitHub.

## ChatGPT connector/action schema

The release includes `openapi_chatgpt_readonly.yaml`. It intentionally defines only GET/read operations. Configure the integration to use the dedicated read-only Bearer token as its secret/credential; do not paste the token into an ordinary conversation.

The schema exposes:

- `/auth/me`
- `/items`
- `/items/{item_id}`
- `/items/{item_id}/photos`
- `/items/{item_id}/photos/{number}`
- `/groups`
- `/statuses`
- `/intake/sessions`
- `/intake/sessions/{session_id}`
- `/intake/sessions/{session_id}/photos/{photo_id}`

No create, update, delete, approval, or eBay operations are included.

## V19 additions for ChatGPT

V19 adds the `read:export` scope to the dedicated ChatGPT token. This allows bulk metadata retrieval and review of filename-matching previews without any permission to alter inventory records.

Useful endpoints:

```text
GET /api/v1/matching/imports
GET /api/v1/matching/imports/{id}
GET /api/v1/logical-groups
GET /api/v1/export/inventory.json
GET /api/v1/export/intake.json
GET /api/v1/export/matching/{id}.json
```

A matching-row approval in the management UI is still only an approval of the **proposal**. V19 does not write those proposals into the master inventory. That remains a later controlled reconciliation step.
